# PR 37 block 5–15 operator packet

Use Linux x86-64, Bash, Git, curl, Python 3, iproute2, util-linux with unprivileged network namespaces enabled, and Node.js 20.20.2 with npm. Allow network access for checkout and dependency installation. Both execution runs use isolated loopback networks. No wallet or source node is needed.

From the unpacked packet directory, with the two tool binaries installed:
```sh
sha256sum --strict -c SHA256SUMS
operator=$(mktemp -d)
git clone https://github.com/Xubu-Trad/cawmmunity.caw-decentralized-social.git "$operator/repo"
git -C "$operator/repo" checkout --detach 68ee9ab52ebbf27827792318b54144c3fbf196a2
bash reproduce.sh "$operator/repo"
```

The script expects Anvil on PATH and the absolute path to the Geth evm tool in GETH_EVM. The linked operator guide includes binary download commands. It checks the exact binaries before starting a node. Original stdout records are reference.jsonl and strict-reference.jsonl; strict-error.txt contains the expected assertion line. SHA256SUMS covers all packet files other than itself.

The comparison must exit 0 and match eleven reconstructed headers, root pairs, slot transitions, transaction hashes and credits. The strict run must exit 1 with SOURCE_HEADER_ROOT_MISMATCH and reproduce the recorded mismatches at heights 5–15. Fresh block hashes can vary with mining time. compare.py validates each run’s internal block references and compares all other fields exactly. The producer and consumer use the same pinned fixture. Independent operator acceptance requires another operator to publish their own results.
