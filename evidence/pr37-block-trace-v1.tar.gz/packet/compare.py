"""Compare two fresh executions while retaining links between run-specific blocks."""
import json
import re
import sys
from pathlib import Path

def normalized(path, strict):
    rows = [json.loads(line) for line in Path(path).read_text().splitlines()]
    if len(rows) != (13 if strict else 14):
        raise ValueError(f"{path}: incomplete or extra records")
    heights = {}
    for index, row in enumerate(rows[1:12], 5):
        entry = row["headerReconstruction"]
        block = entry.pop("block")
        if entry["height"] != index or not re.fullmatch("0x[0-9a-f]{64}", block) or block in heights.values():
            raise ValueError(f"{path}: invalid block at height {index}")
        heights[index] = block
    if rows[0]["firstMismatch"].pop("block") != heights[5]:
        raise ValueError(f"{path}: first mismatch has a different block")
    if not strict:
        post = rows[-1]
        if post.pop("block") != heights[15] or post["window"].pop("parentHash") != heights[14]:
            raise ValueError(f"{path}: post or parent block differs from trace")
    return rows

if __name__ == "__main__":
    expected, actual, mode = sys.argv[1:]
    if mode not in {"comparison", "strict"}:
        raise ValueError("unknown run mode")
    strict = mode == "strict"
    if normalized(expected, strict) != normalized(actual, strict):
        sys.exit(f"{mode}: results differ from pinned reference")
    print(f"{mode}: all stable fields and within-run block references match")
