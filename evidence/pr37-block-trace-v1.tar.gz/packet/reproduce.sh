#!/usr/bin/env bash
set -euo pipefail
packet=$(cd "$(dirname "$0")" && pwd)
repo=$(cd "${1:?supply pinned checkout}" && pwd)
results=$(mktemp -d)
echo "Fresh run logs: $results"
(cd "$packet" && sha256sum --strict -c SHA256SUMS)
test "$(git -C "$repo" rev-parse HEAD)" = 68ee9ab52ebbf27827792318b54144c3fbf196a2
test -z "$(git -C "$repo" status --porcelain --untracked-files=no)"
test "$(node -v)" = v20.20.2
export GETH_EVM=$(realpath "${GETH_EVM:?set the path to the Geth evm tool}")
printf '%s  %s\n' d8cfddad15a8c601e7b069bc5973ad073dbc2d632b8c5ab50e513ef27c53d6da "$GETH_EVM" \
  b47362d2159aa0f2f575320e5e529bb5a91093cb62dc6bd30c0022018aa9f738 "$(command -v anvil)" | sha256sum --strict -c -
cd "$repo"
for dir in integration/local-console integration/local-console/registration experiments/c007-transactions; do
  npm ci --prefix "$dir" --ignore-scripts --no-audit --no-fund
done
cd integration/local-console/registration
run(){
  unshare -Urn sh -ec 'ip link set lo up; exec node test-stake-window.mjs --root-replay "$@"' sh "$@"
}
run --compare-only >"$results/comparison.jsonl" 2>"$results/comparison.stderr"
python3 "$packet/compare.py" "$packet/reference.jsonl" "$results/comparison.jsonl" comparison
status=0
run >"$results/strict.jsonl" 2>"$results/strict.stderr" || status=$?
printf 'comparison=0\nstrict=%s\n' "$status" >"$results/exit-codes.txt"
test "$status" = 1
grep -Fx -f "$packet/strict-error.txt" "$results/strict.stderr"
python3 "$packet/compare.py" "$packet/strict-reference.jsonl" "$results/strict.jsonl" strict
echo "Cross-engine trace reproduced. Strict source-header verification: MISMATCH."
